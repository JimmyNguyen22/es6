export const LOAI_MON = {
    "loai1":"Chay",
    "loai2": "Mặn"
}

export const TINH_TRANG = {
    "0": "Hết",
    "1": "Còn"
}
// loaiMon.loai1 => chay
// loaiMon["loai1"] => chay